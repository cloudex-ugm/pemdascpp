//Contoh kode penggunaan variabel

#include <iostream>
using namespace std;

int main () { 
    int x;                          // Deklarasi variabel x. 
    cin >> x;                       // Inisialisasi x yang merupakan nilai dari masukkan pengguna
    cout << x / 3 << ' ' << x * 2;  // menggunakan nilai x sebagai variabel

    return 0;
}