// Contoh program C++ 
// Menampilkan Hello World dalam C++

#include <iostream>                     // Menambahkan library Input/Output

int main()                              // Fungsi utama berupa fungsi main
{
    std::cout << "Hello , world!\n";    // Yang dinamakan sebuah statement. Selalu diakhiri dengan tanda “;”

    return 0;                           // Statement yang mengakhiri fungsi main
}