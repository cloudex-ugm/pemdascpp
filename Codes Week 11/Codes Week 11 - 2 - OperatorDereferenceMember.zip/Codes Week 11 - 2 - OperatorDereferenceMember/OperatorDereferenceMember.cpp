#include<iostream>
using namespace std;

	int main()
	{
		int M;
		int *ptr;
		M = 5;
		ptr= &M;
		cout << *ptr;
	}


