#include<iostream>
using namespace std;

int main()
{
	int bilangan_bulat = 10;
	float bilangan_pecahan = 3.14;
	char karakter = 'A';
	bool benar_salah = true;
	
	cout << "Ini adalah Bilangan Bulat: " << bilangan_bulat << '\n';
	cout << "Ini adalah Bilangan Pecahan: " << bilangan_pecahan << '\n';
	cout << "Ini adalah Karakter: " << karakter << '\n';
	cout << "Ini adalah Boolean: " << benar_salah << '\n';
	
   return 0;
}