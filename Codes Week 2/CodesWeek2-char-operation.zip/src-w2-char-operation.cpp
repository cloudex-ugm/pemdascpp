#include<iostream>
using namespace std;

int main()
{
	char my_char = 'A';
	
	my_char += 5;	
	cout << my_char << endl; // Hasil: F

	my_char -= 2;
	cout << my_char << endl; // Hasil: D
}