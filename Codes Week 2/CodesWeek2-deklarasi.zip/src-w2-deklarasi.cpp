#include<iostream>
using namespace std;

int main()
{
	int bilangan_bulat0 = 10;
	cout << "Ini adalah Bilangan Bulat: " << bilangan_bulat0 << '\n';
	int bilangan_bulat1(10);
	cout << "Ini adalah Bilangan Bulat: " << bilangan_bulat1 << '\n';
	int bilangan_bulat2{10};	
	cout << "Ini adalah Bilangan Bulat: " << bilangan_bulat2 << '\n';
	
	int bilangan_bulat3;
	cout << "Ini adalah Bilangan Bulat: " << bilangan_bulat2 << '\n';
	
	return 0;
}