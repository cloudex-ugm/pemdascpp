#include<iostream>
using namespace std;

int main()
{
	unsigned int x = 20;
	int y = 30;
	
	cout << x - y << endl;
	
	return 0;
}