#include <iostream>
using namespace std;

int main() {
   cout << "Ukuran char : " << sizeof(char) << endl;
   cout << "Ukuran int : " << sizeof(int) << endl;
   cout << "Ukuran float : " << sizeof(float) << endl;
   cout << "Ukuran double : " << sizeof(double) << endl;
   
   return 0;
}