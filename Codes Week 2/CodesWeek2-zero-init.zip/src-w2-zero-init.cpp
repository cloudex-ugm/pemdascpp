#include <iostream>
using namespace std;

int main() {
	int bilangan_bulat0 = 0;
	int bilangan_bulat1(0); 
	int bilangan_bulat2{0}; 
	int bilangan_bulat3;
	
	cout << bilangan_bulat0 << endl;
	cout << bilangan_bulat1 << endl;
	cout << bilangan_bulat2 << endl;
	cout << bilangan_bulat3 << endl;
   
   return 0;
}