#include<iostream>
#include<string>
using namespace std;

int main()
{
	// Membuat kumpulan (array) karakter
	// untuk merepresentasikan string
	char array_char[7] = "Kuliah";

	// Menggunakan kelas 'string' bawaan
	// untuk merepresentasikan string
	string tipe_string = "Kuliah";

	cout << array_char << endl;
	cout << tipe_string << endl;
}