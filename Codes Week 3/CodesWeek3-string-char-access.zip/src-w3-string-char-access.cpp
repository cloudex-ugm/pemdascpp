#include<iostream>
#include<string>
using namespace std;

int main()
{
	// Inisialiasasi string
	string kuliah="Kuliah Progdas";
	
	// Mengakses karakter-karakter pada variabel 'kuliah;
	char karakter_pertama = kuliah[0];
	char karakter_terakhir = kuliah[13];
	
	cout << karakter_pertama << endl;
	cout << karakter_terakhir << endl;
}