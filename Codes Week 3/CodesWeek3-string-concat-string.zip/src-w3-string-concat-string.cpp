#include<iostream>
#include<string>
using namespace std;

int main()
{
	string kuliah = "Kuliah";
	string progdas = "Progdas";
	
	// Menggabungkan string 'kuliah' dan 'progdas',
	// serta menambahkan spasi.
	string concat_string = kuliah + " " + progdas;
	cout << concat_string << endl;
}