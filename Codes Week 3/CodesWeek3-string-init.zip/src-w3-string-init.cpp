#include<iostream>
#include<string> // Header file 'string' diperlukan untuk mengakses tipe data string
using namespace std;

int main()
{
	// Inisialiasasi string kosong
	string string_kosong; 
	
	// Inisialiasasi string dengan nilai awal
	string kalimat = "Kuliah Pemrograman Dasar";
	
	cout << kalimat << endl;
}