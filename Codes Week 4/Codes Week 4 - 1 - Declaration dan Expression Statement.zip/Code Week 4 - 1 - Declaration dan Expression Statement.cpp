#include <iostream>

using namespace std;

int main()
{   
    int a, b, x;                              // declaration statement (deklarasi variabel a,b,x)
    a = 10; //  inisialisasi
    b = 5;  //  inisialisasi

    // mengubah nilai variabel x
    x = b * 7;                          // expression statement
    
    //print nilai variabel a
    cout << "x = " << x << '\n';        // expression statement

    //print nilai variabel b
    cout << "b = " << b << '\n';        // expression statement
    
    return 0;                           

}