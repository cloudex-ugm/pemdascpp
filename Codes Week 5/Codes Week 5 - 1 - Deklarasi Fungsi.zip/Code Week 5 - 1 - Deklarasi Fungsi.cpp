#include <iostream>

using namespace std;


 // Deklarasi fungsi bernama "fungsiJumlah" dengan tipe return "void"
void fungsiJumlah();

/*  Jika fungsi hanya dideklarasikan seperti ini, kelihatannya tidak terjadi apa-apa,
    sebab fungsi baru dideklarasikan saja. */


// main function merupakan fungsi utama dari sebuah program C++
int main()
{   
    // kosong
    
    return 0;                          
}


